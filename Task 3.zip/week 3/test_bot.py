import sys
import os

sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from src.bot import ChatBot

def test_chatbot():
    print("Loading ChatBot...")
    intents_path = os.path.join(os.path.dirname(__file__), 'data', 'intents.json')
    bot = ChatBot(intents_path)
    
    test_inputs = [
        "Hello!",
        "Can you recommend me a good shonen anime?",
        "Tell me an interesting anime fact.",
        "What's a good romance anime to watch?",
        "Do you know anything about mecha?",  # Expect fallback
        "Goodbye!"
    ]
    
    for user_input in test_inputs:
        print(f"\nYou: {user_input}")
        response = bot.get_response(user_input)
        print(f"Bot: {response}")

if __name__ == "__main__":
    test_chatbot()
