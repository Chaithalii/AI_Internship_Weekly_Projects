from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import numpy as np
from src.preprocess import preprocess_text

class IntentModel:
    def __init__(self, intents_data):
        self.vectorizer = TfidfVectorizer()
        self.intents = intents_data
        self.corpus = []
        self.tags = []
        
        self._prepare_data()
        
    def _prepare_data(self):
        """Prepares the corpus and tags from intents data for training."""
        for intent in self.intents['intents']:
            for pattern in intent['patterns']:
                # Preprocess pattern and add to corpus
                processed_pattern = preprocess_text(pattern)
                self.corpus.append(processed_pattern)
                self.tags.append(intent['tag'])
                
        # Fit the TF-IDF vectorizer on the corpus
        if self.corpus:
            self.tfidf_matrix = self.vectorizer.fit_transform(self.corpus)
            
    def predict_intent(self, text, threshold=0.3):
        """
        Predicts the intent tag for a given text.
        Returns the predicted tag, or None if confidence is below threshold.
        """
        processed_text = preprocess_text(text)
        text_vector = self.vectorizer.transform([processed_text])
        
        # Calculate cosine similarity between the input text and our corpus
        similarities = cosine_similarity(text_vector, self.tfidf_matrix)
        
        # Find the index of the highest similarity score
        best_match_idx = np.argmax(similarities)
        best_score = similarities[0][best_match_idx]
        
        if best_score > threshold:
            return self.tags[best_match_idx]
        else:
            return None
