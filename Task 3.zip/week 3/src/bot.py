import json
import random
import os
from src.model import IntentModel

class ChatBot:
    def __init__(self, intents_file_path):
        self.intents_data = self._load_intents(intents_file_path)
        self.model = IntentModel(self.intents_data)
        
        # Fallback responses when intent is not matched
        self.fallback_responses = [
            "I'm sorry, I didn't quite catch that. Could you rephrase?",
            "Hmm, I don't know much about that. Try asking me for an anime recommendation!",
            "I am still learning! Can you ask me something else about anime?"
        ]

    def _load_intents(self, file_path):
        """Loads intents from a JSON file."""
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"Intents file not found at {file_path}")
            
        with open(file_path, 'r', encoding='utf-8') as f:
            return json.load(f)
            
    def get_response(self, user_input):
        """
        Gets a response for the user input.
        If an intent is matched, returns a random response from that intent.
        Otherwise, returns a fallback response.
        """
        intent_tag = self.model.predict_intent(user_input)
        
        if intent_tag:
            # Find the responses for the predicted intent tag
            for intent in self.intents_data['intents']:
                if intent['tag'] == intent_tag:
                    return random.choice(intent['responses'])
        
        # Return fallback if no intent is confidently matched
        return random.choice(self.fallback_responses)
