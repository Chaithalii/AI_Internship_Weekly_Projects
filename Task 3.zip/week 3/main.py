import os
import sys

# Ensure the src directory is in the path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from src.bot import ChatBot

def main():
    print("="*50)
    print("Initializing Anime Chatbot... (Downloading NLP data if needed)")
    
    intents_path = os.path.join(os.path.dirname(__file__), 'data', 'intents.json')
    
    try:
        bot = ChatBot(intents_path)
    except Exception as e:
        print(f"Failed to initialize chatbot: {e}")
        return

    print("Initialization Complete!")
    print("="*50)
    print("Anime Chatbot is ready! Type 'quit' or 'exit' to stop.")
    print("Ask me for an anime recommendation, trivia, or just say hi!")
    print("="*50)
    
    while True:
        try:
            user_input = input("\nYou: ")
            
            # Check for exit commands
            if user_input.lower() in ['quit', 'exit', 'bye']:
                print(f"Bot: {bot.get_response('bye')}")
                break
                
            if not user_input.strip():
                continue
                
            response = bot.get_response(user_input)
            print(f"Bot: {response}")
            
        except KeyboardInterrupt:
            print("\nBot: Sayonara! See you next time.")
            break
        except Exception as e:
            print(f"\nBot: Oops! Something went wrong. ({e})")

if __name__ == "__main__":
    main()
