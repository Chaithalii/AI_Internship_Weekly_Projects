# **Anime AI Chatbot**



A simple, interactive command-line AI chatbot that specializes in Anime. It uses Natural Language Processing (NLP) to understand user inputs and provides relevant anime recommendations, trivia, and conversational responses.



#### **Features**



Intent Matching: Uses `scikit-learn` (TF-IDF Vectorization and Cosine Similarity) to understand what the user is asking based on predefined patterns.

Text Preprocessing: Uses `NLTK` to clean user input by removing punctuation and stopwords, and lemmatizing words for better accuracy.

Interactive UI: Runs directly in your terminal for a fast and simple chatting experience.

Customizable: Easy to expand by simply adding new tags and responses to a JSON file.



#### **Prerequisites**



\- Python 3.7 or higher

\- pip (Python package installer)



&nbsp;Installation



1\. Navigate to the project directory:

&nbsp;  ```bash

&nbsp;  cd anime\_chatbot

&nbsp;  ```



2\. Install the required dependencies:

&nbsp;  It is recommended to use a virtual environment, but you can install the dependencies globally:

&nbsp;  ```bash

&nbsp;  pip install -r requirements.txt

&nbsp;  ```

&nbsp;  (Note: The chatbot uses `nltk`, `scikit-learn`, and `numpy`)



#### **Usage**



To start chatting with the bot, simply run the `main.py` file:



```bash

python main.py

```



\- The bot will download necessary NLTK language datasets on its first run.

\- Ask questions like: \*"Recommend me a shonen"\*, \*"What is a good romance anime?"\*, or \*"Tell me an anime fact."\*

\- To exit the chat, type `quit`, `exit`, or `bye`.



#### **Project Structure**



```text

anime\_chatbot/

├── data/

│   └── intents.json      # Contains all the intents, training patterns, and responses

├── src/

│   ├── bot.py            # Chatbot class handling prediction and response logic

│   ├── model.py          # TF-IDF and Cosine Similarity model

│   └── preprocess.py     # Text cleaning (tokenization, lemmatization, stop words)

├── main.py               # The main entry point and terminal UI

├── requirements.txt      # Python dependencies

└── test\_bot.py           # A quick script to test bot responses non-interactively

```

#### How to run the AI Chatbot:



cd "c:\\Users\\chait\\OneDrive\\Documents\\ai intership\\anime\_chatbot"

python main.py



#### **How to Add New Knowledge**



You can easily teach the chatbot new things without touching the Python code!

1\. Open `data/intents.json`.

2\. Add a new dictionary object to the list. For example:

&nbsp;  ```json

&nbsp;  {

&nbsp;    "tag": "favorite\_food",

&nbsp;    "patterns": \[

&nbsp;      "What do you like to eat?",

&nbsp;      "What is your favorite food?"

&nbsp;    ],

&nbsp;    "responses": \[

&nbsp;      "I love eating Ramen, just like Naruto!",

&nbsp;      "Digital data is my favorite, but I've always wanted to try Onigiri."

&nbsp;    ]

&nbsp;  }

&nbsp;  ```

3\. Restart the bot! It will automatically re-train its model using the new data.



#### **Author :**



**Name: CHAITHALI D**



**Course: Artificial Intelligence** 



**Project: Week 3 – AI Chatbot**

