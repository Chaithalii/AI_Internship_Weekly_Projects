# **Project Overview**



This project develops a Machine Learning Prediction System using the IBM HR Employee Attrition \& Performance dataset. The objective is to build a predictive model that determines whether an employee is likely to leave the company based on various employee-related features. The project includes data preprocessing, model training, evaluation, and saving the trained model for future predictions.



### **Project Requirements**



\- Load the dataset

\- Data preprocessing

\- Encode categorical features

\- Split the dataset into training and testing sets

\- Train a Machine Learning model

\- Evaluate model performance

\- Save the trained model

\- Predict employee attrition



#### **Dataset**



**Dataset used:** IBM HR Employee Attrition \& Performance Dataset



#### **Requirements Used**



\- Python

\- Jupyter Notebook

\- Pandas

\- NumPy

\- Scikit-learn

\- Matplotlib

\- Seaborn

\- Joblib



#### **Setup Instructions**



Install the required libraries:



pip install -r requirements.txt



Or install them manually:



pip install pandas numpy scikit-learn matplotlib seaborn joblib jupyter notebook



###### **Step 1:** Open Jupyter Notebook

###### 

###### **Step 2:** Open the notebook file

###### 

###### **Step 3:** Import all the required libraries

###### 

###### **Step 4:** Load the dataset

###### 

###### Step 5: Data Preprocessing



The following preprocessing steps were performed:



\- Removed unnecessary columns:

&nbsp; - EmployeeCount

&nbsp; - StandardHours

&nbsp; - Over18

&nbsp; - EmployeeNumber

\- Encoded all categorical variables using Label Encoding.

\- Separated features and target variable.

\- Split the dataset into training and testing sets.

\- Standardized numerical features using StandardScaler.



###### **Step 6:** Model Training



The following Machine Learning model was used:



\- Random Forest Classifier



The model was trained using the training dataset to predict employee attrition.



###### **Step 7:** Model Evaluation



The trained model was evaluated using:



\- Accuracy Score

\- Confusion Matrix

\- Classification Report

###### 

###### **Step 8:** Feature Importance



The project visualizes the Top 10 Most Important Features that influence employee attrition using a bar chart.



Step 9: Save and Load Model



The trained model is saved as:



\- employee\_attrition\_model.pkl



The saved model can be loaded later to make predictions without retraining.



###### **Step 10:** Prediction



The trained model predicts whether an employee is likely to:



\- Stay with the company

\- Leave the company



#### **Key Insights**



\- Random Forest provides high prediction accuracy for employee attrition.

\- Overtime is one of the strongest indicators of employee attrition.

\- Monthly income, job level, total working years, and years at the company significantly influence employee retention.

\- The trained model can be reused for predicting attrition on new employee data.



### **Author**



Name: CHAITHALI D



Course: Artificial Intelligence



Project: Week 2 – Machine Learning Prediction System

