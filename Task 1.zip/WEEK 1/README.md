# **Project Overview**

This project analyzes the IBM HR Employee Attrition \& Performance dataset using Python libraries such as Pandas, NumPy, Matplotlib, and Seaborn.

The objective is to clean and preprocess the data, perform statistical analysis, generate visualizations, and produce a summary report.



#### **Project Requirements**

\- Loading the dataset

\- Cleaning missing values

\- Data preprocessing

\- Statistical analysis

\- Charts and graphs

\- Summary report 



#### **Dataset**



Dataset used: IBM HR Employee Attrition \& Performance Dataset



#### **Requirements Used**



\- Python

\- Jupyter Notebook

\- Pandas

\- NumPy

\- Matplotlib

\- Seaborn



## **Setup instructions**



###### Install the required libraries:



**pip install -r requirements.txt**



###### Or install them manually:



**pip install pandas numpy matplotlib seaborn jupyter notebook**





###### **Step 1:** Open Jupyter Notebook

###### **Step 2:** Open the notebook file

###### **Step 3:** Import all the Libraries

###### **Step 4:** Load the dataset

###### **Step 5:** Data Cleaning



The following steps were performed:



\- Checked for missing values.

\- Filled missing numerical values using the median.

\- Filled missing categorical values using the mode.

\- Removed unnecessary columns:



###### **Step 6:** Data Preprocessing



The following transformations were applied:



\- Converted categorical values into numerical values.

\- Prepared the dataset for statistical analysis and visualization.

###### 

###### **Step 7:** Statistical Analysis



The following analyses were performed:



\- Dataset summary statistics.

\- Employee attrition rate.

\- Department-wise employee distribution.

\- Average age and monthly income.



###### Step 8: Visualizations



The project generates the following charts:



1\. Employee Age Distribution

2\. Attrition by Department

3\. Overtime vs Attrition

4\. Monthly Income Distribution by Job Role

5\. Correlation Heatmap

6\. Attrition count

7\. Attrition vs Montly



###### **Step 9:** Summary report 



-Total Employees: 1470

-Employees Left: 237

-Employees Stayed: 1233

-Overall Attrition Rate: 16.12%



Top Departments:

-Research \& Development    961

-Sales                     446

-Human Resources            63

-Name: Department, dtype: int64



-Average Age: 36.92

-Average Monthly Income: $6502.93

-Average Years at Company: 7.01





##### **Key Insights**



\- Employees working overtime are more likely to leave the company.

\- Younger employees have a higher attrition rate.

\- Lower monthly income is associated with higher employee turnover.

\- Sales and Human Resources departments show higher attrition.





##### **Author**



Name: CHAITHALI D



Course: Artificial Intelligence 



Project: Week 1 – AI Data Analysis \& Visualization



